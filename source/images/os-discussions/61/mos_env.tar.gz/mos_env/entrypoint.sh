#!/bin/bash

set -e

if [ ! -f /home/player/.setup ]; then
    echo "First run, setting up..."
    sudo -u player ssh-keygen -t rsa -N "" -f /home/player/.ssh/id_rsa
    sudo -u player cp /home/player/.ssh/id_rsa.pub /home/player/.ssh/authorized_keys
    echo "Git user configured as 'Player' with email 'player@svc.moe'. You may want to change this after setup."
    git config --global user.email "player@svc.moe"
    git config --global user.name "Player"
    echo "Please wait patiently while the files are being copied..."
    sudo rsync -rahWt --remove-source-files --info=progress2 --info=name0 /player/ /home/player
    echo "Done!"
fi

sudo service ssh start

echo "Now you can connect to the container with the following command:"
echo "ssh -p 4322 player@localhost"

while true; do sleep 1000; done